package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDataRepository
import com.example.model.*
import com.example.ui.components.AdMobInterstitialDialog
import com.example.ui.components.AdMobRewardedPlayer
import com.example.ui.screens.call.CallScreen
import com.example.ui.screens.calls.CallsScreen
import com.example.ui.screens.chat.AddStoryDialog
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.chat.ChatsListScreen
import com.example.ui.screens.chat.StoryViewerDialog
import com.example.ui.screens.contacts.ContactsScreen
import com.example.ui.screens.rooms.VoiceRoomsScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.MyApplicationTheme

enum class NavigationTab {
    CHATS,
    CALLS,
    ROOMS,
    CONTACTS,
    WALLET
}

class MainActivity : ComponentActivity() {
    private val repository = AppDataRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                FFCallApp(
                    repository = repository,
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { isDarkTheme = !isDarkTheme }
                )
            }
        }
    }
}

@Composable
fun FFCallApp(
    repository: AppDataRepository,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit
) {
    var currentTab by remember { mutableStateOf(NavigationTab.CHATS) }
    var selectedContactForChat by remember { mutableStateOf<Contact?>(null) }
    var viewingStory by remember { mutableStateOf<Story?>(null) }
    var showAddStoryDialog by remember { mutableStateOf(false) }

    // State from repository
    val contacts by repository.contacts.collectAsStateWithLifecycle()
    val messages by repository.messages.collectAsStateWithLifecycle()
    val callHistory by repository.callHistory.collectAsStateWithLifecycle()
    val voiceRooms by repository.voiceRooms.collectAsStateWithLifecycle()
    val stories by repository.stories.collectAsStateWithLifecycle()
    val walletBalance by repository.walletBalance.collectAsStateWithLifecycle()
    val transactions by repository.transactions.collectAsStateWithLifecycle()
    val adMobConfig by repository.adMobConfig.collectAsStateWithLifecycle()
    val activeCallSession by repository.activeCallSession.collectAsStateWithLifecycle()
    val showInterstitialAd by repository.showInterstitialAd.collectAsStateWithLifecycle()
    val showRewardedAdPlayer by repository.showRewardedAdPlayer.collectAsStateWithLifecycle()

    // Handle system back navigation
    BackHandler(enabled = selectedContactForChat != null || activeCallSession != null) {
        if (activeCallSession != null) {
            repository.endCall()
        } else if (selectedContactForChat != null) {
            selectedContactForChat = null
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only show bottom navigation when not in an active call and not inside single chat detail
            if (activeCallSession == null && selectedContactForChat == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.CHATS,
                        onClick = { currentTab = NavigationTab.CHATS },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.ChatBubble,
                                contentDescription = "Chats"
                            )
                        },
                        label = { Text("Chats", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0084FF),
                            selectedTextColor = Color(0xFF0084FF),
                            indicatorColor = Color(0xFF0084FF).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_chats")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.CALLS,
                        onClick = { currentTab = NavigationTab.CALLS },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Calls"
                            )
                        },
                        label = { Text("Calls", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0084FF),
                            selectedTextColor = Color(0xFF0084FF),
                            indicatorColor = Color(0xFF0084FF).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_calls")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.ROOMS,
                        onClick = { currentTab = NavigationTab.ROOMS },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = "Rooms"
                            )
                        },
                        label = { Text("Rooms", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0084FF),
                            selectedTextColor = Color(0xFF0084FF),
                            indicatorColor = Color(0xFF0084FF).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_rooms")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.CONTACTS,
                        onClick = { currentTab = NavigationTab.CONTACTS },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Contacts,
                                contentDescription = "Contacts"
                            )
                        },
                        label = { Text("Contacts", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0084FF),
                            selectedTextColor = Color(0xFF0084FF),
                            indicatorColor = Color(0xFF0084FF).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_contacts")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.WALLET,
                        onClick = { currentTab = NavigationTab.WALLET },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Wallet"
                            )
                        },
                        label = { Text("Wallet", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFFB800),
                            selectedTextColor = Color(0xFFFFB800),
                            indicatorColor = Color(0xFFFFB800).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_wallet")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedContactForChat != null) {
                // ONE-TO-ONE CHAT DETAIL SCREEN
                val contact = selectedContactForChat!!
                val chatMsgs = messages[contact.id] ?: emptyList()
                ChatDetailScreen(
                    contact = contact,
                    messages = chatMsgs,
                    adMobConfig = adMobConfig,
                    onBack = { selectedContactForChat = null },
                    onStartAudioCall = { c -> repository.startCall(c, isVideo = false) },
                    onStartVideoCall = { c -> repository.startCall(c, isVideo = true) },
                    onSendMessage = { text, type, fileName, fileSize, voiceDur ->
                        repository.sendMessage(contact.id, text, type, fileName, fileSize, voiceDur)
                    }
                )
            } else {
                // MAIN TABS
                when (currentTab) {
                    NavigationTab.CHATS -> {
                        ChatsListScreen(
                            contacts = contacts,
                            messages = messages,
                            stories = stories,
                            adMobConfig = adMobConfig,
                            walletBalance = walletBalance,
                            onSelectContact = { contact -> selectedContactForChat = contact },
                            onOpenStory = { story -> viewingStory = story },
                            onAddStory = { showAddStoryDialog = true },
                            onWatchAdToEarn = { repository.openRewardedAd() }
                        )
                    }
                    NavigationTab.CALLS -> {
                        CallsScreen(
                            callHistory = callHistory,
                            onCallBack = { record ->
                                val contact = contacts.find { it.id == record.contactId } ?: Contact(
                                    id = record.contactId,
                                    name = record.contactName,
                                    phone = record.contactPhone,
                                    avatarInitials = record.avatarInitials
                                )
                                repository.startCall(contact, isVideo = record.isVideo)
                            },
                            onSimulateIncomingCall = {
                                repository.simulateIncomingCall()
                            }
                        )
                    }
                    NavigationTab.ROOMS -> {
                        VoiceRoomsScreen(
                            rooms = voiceRooms,
                            onCreateRoom = { title, category ->
                                repository.createVoiceRoom(title, category)
                            }
                        )
                    }
                    NavigationTab.CONTACTS -> {
                        ContactsScreen(
                            contacts = contacts,
                            onSelectContact = { contact -> selectedContactForChat = contact },
                            onStartAudioCall = { contact -> repository.startCall(contact, isVideo = false) },
                            onStartVideoCall = { contact -> repository.startCall(contact, isVideo = true) }
                        )
                    }
                    NavigationTab.WALLET -> {
                        WalletScreen(
                            balance = walletBalance,
                            transactions = transactions,
                            adMobConfig = adMobConfig,
                            onWatchAdToEarn = { repository.openRewardedAd() },
                            onClaimDailyBonus = { repository.claimDailyBonus() },
                            onRequestWithdrawal = { method, number, amount ->
                                repository.requestWithdrawal(method, number, amount)
                            },
                            onUpdateAdMobConfig = { newConfig ->
                                repository.updateAdMobConfig(newConfig)
                            }
                        )
                    }
                }
            }

            // FULL-SCREEN ACTIVE CALL SCREEN OVERLAY
            if (activeCallSession != null) {
                CallScreen(
                    session = activeCallSession!!,
                    onEndCall = { repository.endCall() },
                    onAnswerCall = { repository.answerIncomingCall() },
                    onToggleMute = { repository.toggleMute() },
                    onToggleSpeaker = { repository.toggleSpeaker() },
                    onToggleCamera = { repository.toggleCamera() },
                    onToggleScreenShare = { repository.toggleScreenShare() },
                    onFlipCamera = { repository.flipCamera() }
                )
            }

            // GOOGLE ADMOB INTERSTITIAL AD (TRIGGERED AFTER FINISHING A CALL)
            if (showInterstitialAd) {
                AdMobInterstitialDialog(
                    config = adMobConfig,
                    onDismiss = { repository.dismissInterstitialAd() }
                )
            }

            // GOOGLE ADMOB REWARDED VIDEO AD PLAYER (WATCH AD & EARN +৳5.00)
            if (showRewardedAdPlayer) {
                AdMobRewardedPlayer(
                    config = adMobConfig,
                    onCompleted = { repository.closeRewardedAd(wasCompleted = true) },
                    onCancelled = { repository.closeRewardedAd(wasCompleted = false) }
                )
            }

            // STORY VIEWER DIALOG
            if (viewingStory != null) {
                val initialIndex = stories.indexOf(viewingStory).coerceAtLeast(0)
                StoryViewerDialog(
                    stories = stories,
                    initialIndex = initialIndex,
                    onDismiss = { viewingStory = null }
                )
            }

            // ADD STORY DIALOG
            if (showAddStoryDialog) {
                AddStoryDialog(
                    onDismiss = { showAddStoryDialog = false },
                    onPublish = { caption, bgIndex ->
                        repository.addStory(caption, bgIndex)
                    }
                )
            }
        }
    }
}
