package com.example.data

import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AppDataRepository {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var callTimerJob: Job? = null

    // Contacts
    private val _contacts = MutableStateFlow<List<Contact>>(emptyList())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    // Messages grouped by contactId
    private val _messages = MutableStateFlow<Map<String, List<ChatMessage>>>(emptyMap())
    val messages: StateFlow<Map<String, List<ChatMessage>>> = _messages.asStateFlow()

    // Call History
    private val _callHistory = MutableStateFlow<List<CallRecord>>(emptyList())
    val callHistory: StateFlow<List<CallRecord>> = _callHistory.asStateFlow()

    // Active Call
    private val _activeCallSession = MutableStateFlow<CallSession?>(null)
    val activeCallSession: StateFlow<CallSession?> = _activeCallSession.asStateFlow()

    // Voice Rooms
    private val _voiceRooms = MutableStateFlow<List<VoiceRoom>>(emptyList())
    val voiceRooms: StateFlow<List<VoiceRoom>> = _voiceRooms.asStateFlow()

    // Stories
    private val _stories = MutableStateFlow<List<Story>>(emptyList())
    val stories: StateFlow<List<Story>> = _stories.asStateFlow()

    // Wallet & Earnings
    private val _walletBalance = MutableStateFlow(35.0)
    val walletBalance: StateFlow<Double> = _walletBalance.asStateFlow()

    private val _transactions = MutableStateFlow<List<WalletTransaction>>(emptyList())
    val transactions: StateFlow<List<WalletTransaction>> = _transactions.asStateFlow()

    // AdMob Config
    private val _adMobConfig = MutableStateFlow(AdMobConfig())
    val adMobConfig: StateFlow<AdMobConfig> = _adMobConfig.asStateFlow()

    // Ad Triggers
    private val _showInterstitialAd = MutableStateFlow(false)
    val showInterstitialAd: StateFlow<Boolean> = _showInterstitialAd.asStateFlow()

    private val _showRewardedAdPlayer = MutableStateFlow(false)
    val showRewardedAdPlayer: StateFlow<Boolean> = _showRewardedAdPlayer.asStateFlow()

    private val _lastRewardEarned = MutableStateFlow<Double?>(null)
    val lastRewardEarned: StateFlow<Double?> = _lastRewardEarned.asStateFlow()

    init {
        initDefaultData()
    }

    private fun currentTimeString(): String {
        return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
    }

    private fun initDefaultData() {
        val initialContacts = listOf(
            Contact(
                id = "c1",
                name = "Tanvir Hasan",
                phone = "+880 1711-234567",
                avatarInitials = "TH",
                avatarBgColor = 0xFF0084FF,
                isOnline = true,
                statusMessage = "Busy in studio. Call on FF Call!",
                unreadCount = 2
            ),
            Contact(
                id = "c2",
                name = "Sarah Ahmed",
                phone = "+880 1822-345678",
                avatarInitials = "SA",
                avatarBgColor = 0xFFEC4899,
                isOnline = true,
                statusMessage = "HD Video call is so clear here!",
                unreadCount = 0
            ),
            Contact(
                id = "c3",
                name = "Rafi Islam",
                phone = "+880 1933-456789",
                avatarInitials = "RI",
                avatarBgColor = 0xFF10B981,
                isOnline = false,
                lastSeen = "15 min ago",
                statusMessage = "Available for audio chat.",
                unreadCount = 0
            ),
            Contact(
                id = "c4",
                name = "Nusrat Jahan",
                phone = "+880 1644-567890",
                avatarInitials = "NJ",
                avatarBgColor = 0xFF8B5CF6,
                isOnline = true,
                statusMessage = "Join my Voice Club room tonight!",
                unreadCount = 1
            ),
            Contact(
                id = "c5",
                name = "Mom ❤️",
                phone = "+880 1555-678901",
                avatarInitials = "M",
                avatarBgColor = 0xFFF59E0B,
                isOnline = true,
                statusMessage = "Call me whenever you are free.",
                unreadCount = 0
            ),
            Contact(
                id = "c6",
                name = "Dhaka Hangout Group",
                phone = "8 members",
                avatarInitials = "DH",
                avatarBgColor = 0xFF00C2CB,
                isOnline = true,
                statusMessage = "Group voice call scheduled at 9 PM",
                unreadCount = 4
            )
        )
        _contacts.value = initialContacts

        val initialMessages = mapOf(
            "c1" to listOf(
                ChatMessage(
                    id = "m1",
                    contactId = "c1",
                    senderName = "Tanvir Hasan",
                    isMe = false,
                    text = "Hey! Did you try the new WebRTC HD call in FF Call?",
                    timestamp = "10:30 AM",
                    status = MessageStatus.READ
                ),
                ChatMessage(
                    id = "m2",
                    contactId = "c1",
                    senderName = "Me",
                    isMe = true,
                    text = "Yes, audio is crystal clear even on 3G network! End-to-end encrypted too.",
                    timestamp = "10:32 AM",
                    status = MessageStatus.READ
                ),
                ChatMessage(
                    id = "m3",
                    contactId = "c1",
                    senderName = "Tanvir Hasan",
                    isMe = false,
                    text = "I also earned ৳20 by watching rewarded ads today!",
                    timestamp = "10:35 AM",
                    status = MessageStatus.READ
                )
            ),
            "c2" to listOf(
                ChatMessage(
                    id = "m21",
                    contactId = "c2",
                    senderName = "Sarah Ahmed",
                    isMe = false,
                    text = "Check out this document for our project meeting.",
                    timestamp = "Yesterday",
                    status = MessageStatus.READ,
                    type = MessageType.FILE,
                    fileName = "FF_Call_Architecture_v2.pdf",
                    fileSize = "2.4 MB"
                ),
                ChatMessage(
                    id = "m22",
                    contactId = "c2",
                    senderName = "Sarah Ahmed",
                    isMe = false,
                    text = "Voice message",
                    timestamp = "Yesterday",
                    status = MessageStatus.READ,
                    type = MessageType.VOICE,
                    voiceDurationSec = 14
                )
            )
        )
        _messages.value = initialMessages

        val initialCallHistory = listOf(
            CallRecord(
                id = "cr1",
                contactId = "c1",
                contactName = "Tanvir Hasan",
                contactPhone = "+880 1711-234567",
                avatarInitials = "TH",
                direction = CallDirection.INCOMING,
                isVideo = true,
                timestamp = "Today, 11:15 AM",
                duration = "08:42"
            ),
            CallRecord(
                id = "cr2",
                contactId = "c2",
                contactName = "Sarah Ahmed",
                contactPhone = "+880 1822-345678",
                avatarInitials = "SA",
                direction = CallDirection.OUTGOING,
                isVideo = false,
                timestamp = "Today, 09:20 AM",
                duration = "03:15"
            ),
            CallRecord(
                id = "cr3",
                contactId = "c4",
                contactName = "Nusrat Jahan",
                contactPhone = "+880 1644-567890",
                avatarInitials = "NJ",
                direction = CallDirection.MISSED,
                isVideo = true,
                timestamp = "Yesterday, 07:45 PM",
                duration = "Missed"
            ),
            CallRecord(
                id = "cr4",
                contactId = "c5",
                contactName = "Mom ❤️",
                contactPhone = "+880 1555-678901",
                avatarInitials = "M",
                direction = CallDirection.INCOMING,
                isVideo = false,
                timestamp = "Yesterday, 02:10 PM",
                duration = "14:20"
            )
        )
        _callHistory.value = initialCallHistory

        val initialRooms = listOf(
            VoiceRoom(
                id = "r1",
                title = "Dhaka Chill & Music Club 🎵",
                hostName = "Tanvir Hasan",
                category = "Music & Chat",
                membersCount = 142,
                speakers = listOf(
                    RoomSpeaker("Tanvir", "T", isSpeaking = true),
                    RoomSpeaker("Sarah", "S", isSpeaking = false),
                    RoomSpeaker("Arefin", "A", isSpeaking = true),
                    RoomSpeaker("Nusrat", "N", isSpeaking = false)
                )
            ),
            VoiceRoom(
                id = "r2",
                title = "Gaming & Esports Squad 🎮",
                hostName = "Rafi Islam",
                category = "Gaming",
                membersCount = 89,
                speakers = listOf(
                    RoomSpeaker("Rafi", "R", isSpeaking = true),
                    RoomSpeaker("Fahim", "F", isSpeaking = false),
                    RoomSpeaker("Shakib", "S", isSpeaking = true)
                )
            ),
            VoiceRoom(
                id = "r3",
                title = "English Practice & Global Friends 🌍",
                hostName = "Emily & Kabir",
                category = "Language",
                membersCount = 230,
                speakers = listOf(
                    RoomSpeaker("Emily", "E", isSpeaking = false),
                    RoomSpeaker("Kabir", "K", isSpeaking = true),
                    RoomSpeaker("Zayan", "Z", isSpeaking = false),
                    RoomSpeaker("Nafis", "N", isSpeaking = true)
                )
            )
        )
        _voiceRooms.value = initialRooms

        val initialStories = listOf(
            Story(
                id = "s1",
                authorName = "Tanvir Hasan",
                avatarChar = "T",
                timestamp = "2h ago",
                caption = "Audio room party was lit tonight! 🔥",
                bgGradientIndex = 0
            ),
            Story(
                id = "s2",
                authorName = "Sarah Ahmed",
                avatarChar = "S",
                timestamp = "4h ago",
                caption = "Sunset in Cox's Bazar 🌅 Amazing video call quality!",
                bgGradientIndex = 1
            ),
            Story(
                id = "s3",
                authorName = "Nusrat Jahan",
                avatarChar = "N",
                timestamp = "6h ago",
                caption = "Earned ৳50 from rewarded video ads on FF Call! 💰",
                bgGradientIndex = 2
            )
        )
        _stories.value = initialStories

        val initialTransactions = listOf(
            WalletTransaction(
                id = "t1",
                title = "Welcome Bonus",
                description = "Account registration reward",
                amountTaka = 15.0,
                timestamp = "Oct 12, 10:00 AM",
                isCredit = true
            ),
            WalletTransaction(
                id = "t2",
                title = "Rewarded Video Ad",
                description = "Google AdMob Rewarded Bonus",
                amountTaka = 5.0,
                timestamp = "Oct 12, 02:30 PM",
                isCredit = true
            ),
            WalletTransaction(
                id = "t3",
                title = "Rewarded Video Ad",
                description = "Google AdMob Rewarded Bonus",
                amountTaka = 5.0,
                timestamp = "Oct 13, 09:15 AM",
                isCredit = true
            ),
            WalletTransaction(
                id = "t4",
                title = "Daily Check-in Bonus",
                description = "Day 2 Login Reward",
                amountTaka = 2.0,
                timestamp = "Oct 13, 11:00 AM",
                isCredit = true
            ),
            WalletTransaction(
                id = "t5",
                title = "Rewarded Video Ad",
                description = "Google AdMob Rewarded Bonus",
                amountTaka = 5.0,
                timestamp = "Oct 13, 01:45 PM",
                isCredit = true
            ),
            WalletTransaction(
                id = "t6",
                title = "Call Quality Reward",
                description = "Completed 5+ min HD Call",
                amountTaka = 3.0,
                timestamp = "Oct 13, 02:15 PM",
                isCredit = true
            )
        )
        _transactions.value = initialTransactions
    }

    // Chat actions
    fun sendMessage(
        contactId: String,
        text: String,
        type: MessageType = MessageType.TEXT,
        fileName: String? = null,
        fileSize: String? = null,
        voiceDurationSec: Int = 0
    ) {
        val contact = _contacts.value.find { it.id == contactId } ?: return
        val newMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            contactId = contactId,
            senderName = "Me",
            isMe = true,
            text = text,
            timestamp = currentTimeString(),
            status = MessageStatus.SENT,
            type = type,
            fileName = fileName,
            fileSize = fileSize,
            voiceDurationSec = voiceDurationSec,
            isEncrypted = true
        )

        _messages.update { current ->
            val list = current[contactId]?.toMutableList() ?: mutableListOf()
            list.add(newMsg)
            current + (contactId to list)
        }

        // Simulate delivery & read
        scope.launch {
            delay(1000)
            _messages.update { current ->
                val list = current[contactId]?.map {
                    if (it.id == newMsg.id) it.copy(status = MessageStatus.DELIVERED) else it
                } ?: emptyList()
                current + (contactId to list)
            }
            delay(1500)
            _messages.update { current ->
                val list = current[contactId]?.map {
                    if (it.id == newMsg.id) it.copy(status = MessageStatus.READ) else it
                } ?: emptyList()
                current + (contactId to list)
            }

            // Simulate auto reply from contact if text message
            if (type == MessageType.TEXT && !text.isBlank()) {
                delay(1200)
                val replyText = when {
                    text.contains("call", ignoreCase = true) -> "Sure! Tap the call button above to start an HD video/audio call."
                    text.contains("ad", ignoreCase = true) || text.contains("earn", ignoreCase = true) -> "Yes! Tap 'Watch Ad & Earn' to get ৳5 instantly."
                    text.contains("hi", ignoreCase = true) || text.contains("hello", ignoreCase = true) -> "Hello! How are you doing today?"
                    else -> "Got your encrypted message! The WebRTC audio and video latency here is amazing."
                }
                val replyMsg = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    contactId = contactId,
                    senderName = contact.name,
                    isMe = false,
                    text = replyText,
                    timestamp = currentTimeString(),
                    status = MessageStatus.READ,
                    isEncrypted = true
                )
                _messages.update { current ->
                    val list = current[contactId]?.toMutableList() ?: mutableListOf()
                    list.add(replyMsg)
                    current + (contactId to list)
                }
            }
        }
    }

    // Calling Actions
    fun startCall(contact: Contact, isVideo: Boolean) {
        val session = CallSession(
            contact = contact,
            isVideo = isVideo,
            isIncoming = false,
            isConnected = false
        )
        _activeCallSession.value = session

        // Connect after 2.5 seconds
        callTimerJob?.cancel()
        callTimerJob = scope.launch {
            delay(2500)
            _activeCallSession.update { it?.copy(isConnected = true) }
            startCallTicker()
        }
    }

    fun simulateIncomingCall(contact: Contact? = null, isVideo: Boolean = true) {
        val caller = contact ?: _contacts.value.firstOrNull() ?: return
        callTimerJob?.cancel()
        _activeCallSession.value = CallSession(
            contact = caller,
            isVideo = isVideo,
            isIncoming = true,
            isConnected = false
        )
    }

    fun answerIncomingCall() {
        _activeCallSession.update { it?.copy(isIncoming = false, isConnected = true) }
        startCallTicker()
    }

    private fun startCallTicker() {
        callTimerJob?.cancel()
        callTimerJob = scope.launch {
            while (true) {
                delay(1000)
                _activeCallSession.update { current ->
                    if (current != null && current.isConnected) {
                        current.copy(durationSeconds = current.durationSeconds + 1)
                    } else {
                        current
                    }
                }
            }
        }
    }

    fun toggleMute() {
        _activeCallSession.update { it?.copy(isMuted = !(it.isMuted)) }
    }

    fun toggleSpeaker() {
        _activeCallSession.update { it?.copy(isSpeakerOn = !(it.isSpeakerOn)) }
    }

    fun toggleCamera() {
        _activeCallSession.update { it?.copy(isCameraOn = !(it.isCameraOn)) }
    }

    fun toggleScreenShare() {
        _activeCallSession.update { it?.copy(isScreenSharing = !(it.isScreenSharing)) }
    }

    fun flipCamera() {
        _activeCallSession.update { it?.copy(isFrontCamera = !(it.isFrontCamera)) }
    }

    fun endCall() {
        val session = _activeCallSession.value
        callTimerJob?.cancel()
        callTimerJob = null
        _activeCallSession.value = null

        if (session != null) {
            val durationMin = session.durationSeconds / 60
            val durationSec = session.durationSeconds % 60
            val durString = String.format(Locale.US, "%02d:%02d", durationMin, durationSec)

            val record = CallRecord(
                id = UUID.randomUUID().toString(),
                contactId = session.contact.id,
                contactName = session.contact.name,
                contactPhone = session.contact.phone,
                avatarInitials = session.contact.avatarInitials,
                direction = if (session.isIncoming) {
                    if (session.isConnected) CallDirection.INCOMING else CallDirection.MISSED
                } else {
                    CallDirection.OUTGOING
                },
                isVideo = session.isVideo,
                timestamp = "Just now",
                duration = if (session.isConnected) durString else "Missed"
            )
            _callHistory.update { listOf(record) + it }

            // Trigger Google AdMob Interstitial Ad immediately after finishing call as required!
            _showInterstitialAd.value = true
        }
    }

    fun dismissInterstitialAd() {
        _showInterstitialAd.value = false
    }

    // Rewarded Ad Actions
    fun openRewardedAd() {
        _showRewardedAdPlayer.value = true
    }

    fun closeRewardedAd(wasCompleted: Boolean) {
        _showRewardedAdPlayer.value = false
        if (wasCompleted) {
            val rewardAmount = _adMobConfig.value.rewardAmountTaka
            _walletBalance.update { it + rewardAmount }
            _lastRewardEarned.value = rewardAmount

            val transaction = WalletTransaction(
                id = UUID.randomUUID().toString(),
                title = "Rewarded Video Ad Bonus",
                description = "Google AdMob unit: ${_adMobConfig.value.rewardedUnitId.take(16)}...",
                amountTaka = rewardAmount,
                timestamp = "Just now",
                isCredit = true
            )
            _transactions.update { listOf(transaction) + it }
        }
    }

    fun clearLastRewardNotification() {
        _lastRewardEarned.value = null
    }

    fun claimDailyBonus(): Boolean {
        val bonus = 2.0
        _walletBalance.update { it + bonus }
        val transaction = WalletTransaction(
            id = UUID.randomUUID().toString(),
            title = "Daily Check-in Bonus",
            description = "Day streak active",
            amountTaka = bonus,
            timestamp = "Just now",
            isCredit = true
        )
        _transactions.update { listOf(transaction) + it }
        return true
    }

    fun requestWithdrawal(method: String, number: String, amount: Double): Pair<Boolean, String> {
        if (amount < 20.0) {
            return Pair(false, "Minimum cashout amount is ৳ 20.00")
        }
        if (_walletBalance.value < amount) {
            return Pair(false, "Insufficient balance! Your balance is ৳ ${_walletBalance.value}")
        }
        if (number.length < 11) {
            return Pair(false, "Please enter a valid 11-digit mobile number")
        }

        _walletBalance.update { it - amount }
        val transaction = WalletTransaction(
            id = UUID.randomUUID().toString(),
            title = "Cashout via $method",
            description = "Sent to $number",
            amountTaka = amount,
            timestamp = "Just now",
            isCredit = false
        )
        _transactions.update { listOf(transaction) + it }
        return Pair(true, "Withdrawal request of ৳ $amount submitted successfully! Transfer in progress.")
    }

    fun updateAdMobConfig(newConfig: AdMobConfig) {
        _adMobConfig.value = newConfig
    }

    fun addStory(caption: String, bgGradientIndex: Int) {
        val story = Story(
            id = UUID.randomUUID().toString(),
            authorName = "My Story",
            avatarChar = "ME",
            timestamp = "Just now",
            caption = caption,
            bgGradientIndex = bgGradientIndex,
            isSeen = false
        )
        _stories.update { listOf(story) + it }
    }

    fun createVoiceRoom(title: String, category: String) {
        val room = VoiceRoom(
            id = UUID.randomUUID().toString(),
            title = title,
            hostName = "You (Host)",
            category = category,
            membersCount = 1,
            speakers = listOf(
                RoomSpeaker("You", "Y", isSpeaking = true)
            )
        )
        _voiceRooms.update { listOf(room) + it }
    }
}
