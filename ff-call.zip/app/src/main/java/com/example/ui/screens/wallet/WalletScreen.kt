package com.example.ui.screens.wallet

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdMobConfig
import com.example.model.WalletTransaction

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    balance: Double,
    transactions: List<WalletTransaction>,
    adMobConfig: AdMobConfig,
    onWatchAdToEarn: () -> Unit,
    onClaimDailyBonus: () -> Unit,
    onRequestWithdrawal: (method: String, number: String, amount: Double) -> Pair<Boolean, String>,
    onUpdateAdMobConfig: (AdMobConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var showWithdrawDialog by remember { mutableStateOf(false) }
    var showAdminSettingsDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = Color(0xFFFFB800)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Wallet & Rewards",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showAdminSettingsDialog = true },
                        modifier = Modifier.testTag("open_admin_admob_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "AdMob Admin Settings",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Status Snackbar / Message
            if (statusMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF064E3B)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = statusMessage!!,
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { statusMessage = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Main Balance Golden Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("wallet_balance_card"),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFD97706),
                                        Color(0xFFF59E0B),
                                        Color(0xFFFBBF24)
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "TOTAL BALANCE",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.9f),
                                    letterSpacing = 1.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "Currency: BDT (৳)",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "৳ ${String.format("%.2f", balance)}",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )

                            Text(
                                text = "Available for instant bKash / Nagad / Rocket cashout",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { showWithdrawDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("wallet_cashout_button")
                                ) {
                                    Text(
                                        text = "Cashout",
                                        color = Color(0xFFB45309),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                OutlinedButton(
                                    onClick = onClaimDailyBonus,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = Color.White
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(Color.White, Color.White))
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "Daily +৳2",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // High-Value Monetization / Watch Ad & Earn Banner (MANDATORY REQUIREMENT)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("watch_ad_and_earn_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF0084FF).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF0084FF),
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Watch Ad & Earn",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Get +৳ ${String.format("%.2f", adMobConfig.rewardAmountTaka)} bonus per video ad",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFFFB800).copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "+৳ ${String.format("%.0f", adMobConfig.rewardAmountTaka)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD97706)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = onWatchAdToEarn,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("watch_ad_earn_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0084FF)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Watch Video Ad Now (+৳ ${String.format("%.0f", adMobConfig.rewardAmountTaka)})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Quick Info & Rules
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Earning Rules & Withdrawal Policy",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• Minimum cashout threshold is ৳ 20.00\n• Payments sent instantly to bKash / Nagad / Rocket\n• Earn rewards by watching AdMob videos and making HD calls",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Transactions Header
            item {
                Text(
                    text = "Transaction History",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Transactions List
            items(transactions, key = { it.id }) { tx ->
                TransactionItemRow(tx)
            }
        }
    }

    if (showWithdrawDialog) {
        WithdrawDialog(
            balance = balance,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { method, number, amount ->
                val result = onRequestWithdrawal(method, number, amount)
                statusMessage = result.second
                showWithdrawDialog = false
            }
        )
    }

    if (showAdminSettingsDialog) {
        AdminAdMobSettingsDialog(
            config = adMobConfig,
            onDismiss = { showAdminSettingsDialog = false },
            onSave = { newConfig ->
                onUpdateAdMobConfig(newConfig)
                statusMessage = "AdMob Ad Unit IDs and settings saved successfully!"
                showAdminSettingsDialog = false
            }
        )
    }
}

@Composable
fun TransactionItemRow(tx: WalletTransaction) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (tx.isCredit) Color(0xFF10B981).copy(alpha = 0.15f)
                            else Color(0xFFEF4444).copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (tx.isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (tx.isCredit) Color(0xFF10B981) else Color(0xFFEF4444),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = tx.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${tx.timestamp} • ${tx.description}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = "${if (tx.isCredit) "+" else "-"}৳ ${String.format("%.2f", tx.amountTaka)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (tx.isCredit) Color(0xFF10B981) else Color(0xFFEF4444)
            )
        }
    }
}

@Composable
fun WithdrawDialog(
    balance: Double,
    onDismiss: () -> Unit,
    onSubmit: (method: String, number: String, amount: Double) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("bKash") }
    var phoneNumber by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("25") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val methods = listOf("bKash", "Nagad", "Rocket", "Recharge")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Withdraw Earnings", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Current Balance: ৳ ${String.format("%.2f", balance)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFD97706)
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text("Select Payout Method", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    methods.forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method },
                            label = { Text(method, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text("Account / Mobile Number") },
                    placeholder = { Text("017XXXXXXXX") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (Taka)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorText!!,
                        color = Color(0xFFEF4444),
                        fontSize = 11.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt < 20.0) {
                        errorText = "Minimum withdrawal is ৳ 20.00"
                    } else if (amt > balance) {
                        errorText = "Insufficient balance!"
                    } else if (phoneNumber.length < 11) {
                        errorText = "Enter valid 11-digit mobile number"
                    } else {
                        onSubmit(selectedMethod, phoneNumber, amt)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0084FF))
            ) {
                Text("Confirm Cashout", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AdminAdMobSettingsDialog(
    config: AdMobConfig,
    onDismiss: () -> Unit,
    onSave: (AdMobConfig) -> Unit
) {
    var bannerId by remember { mutableStateOf(config.bannerUnitId) }
    var interstitialId by remember { mutableStateOf(config.interstitialUnitId) }
    var rewardedId by remember { mutableStateOf(config.rewardedUnitId) }
    var rewardAmount by remember { mutableStateOf(config.rewardAmountTaka.toString()) }
    var isTestMode by remember { mutableStateOf(config.isTestMode) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = Color(0xFF0084FF)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("AdMob Admin Config", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "Customize Google AdMob Ad Unit IDs and monetization reward rates:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                item {
                    OutlinedTextField(
                        value = bannerId,
                        onValueChange = { bannerId = it },
                        label = { Text("Banner Ad Unit ID", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = interstitialId,
                        onValueChange = { interstitialId = it },
                        label = { Text("Interstitial Ad Unit ID", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = rewardedId,
                        onValueChange = { rewardedId = it },
                        label = { Text("Rewarded Ad Unit ID", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = rewardAmount,
                        onValueChange = { rewardAmount = it },
                        label = { Text("Bonus Taka per Video Ad (৳)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AdMob Test Mode", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = isTestMode,
                            onCheckedChange = { isTestMode = it }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedReward = rewardAmount.toDoubleOrNull() ?: 5.0
                    onSave(
                        config.copy(
                            bannerUnitId = bannerId.trim(),
                            interstitialUnitId = interstitialId.trim(),
                            rewardedUnitId = rewardedId.trim(),
                            rewardAmountTaka = parsedReward,
                            isTestMode = isTestMode
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0084FF))
            ) {
                Text("Save Settings", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    // Reset to standard Google AdMob demo IDs
                    bannerId = "ca-app-pub-3940256099942544/6300978111"
                    interstitialId = "ca-app-pub-3940256099942544/1033173712"
                    rewardedId = "ca-app-pub-3940256099942544/5224354917"
                    rewardAmount = "5.0"
                    isTestMode = true
                }
            ) {
                Text("Defaults")
            }
        }
    )
}
