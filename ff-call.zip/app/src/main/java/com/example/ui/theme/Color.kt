package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Imo Signature Vibrant Blue Palette
val ImoPrimaryBlue = Color(0xFF0084FF)
val ImoLightBlue = Color(0xFF38A3FF)
val ImoDarkBlue = Color(0xFF0066CC)
val ImoDeepBlue = Color(0xFF004CB3)

val ImoCyan = Color(0xFF00C2CB)
val ImoGreenOnline = Color(0xFF10B981)
val ImoRewardGold = Color(0xFFFFB800)
val ImoRewardGoldDark = Color(0xFFE6A600)
val ImoRedEndCall = Color(0xFFEF4444)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightDivider = Color(0xFFE2E8F0)
val LightBubbleIncoming = Color(0xFFFFFFFF)
val LightBubbleOutgoing = Color(0xFF0084FF)

// Dark Theme Palette
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkDivider = Color(0xFF334155)
val DarkBubbleIncoming = Color(0xFF1E293B)
val DarkBubbleOutgoing = Color(0xFF0072E5)
