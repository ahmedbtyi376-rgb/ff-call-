package com.example.ui.screens.calls

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CallDirection
import com.example.model.CallRecord

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallsScreen(
    callHistory: List<CallRecord>,
    onCallBack: (CallRecord) -> Unit,
    onSimulateIncomingCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("All Calls", "Missed")

    val filteredRecords = remember(callHistory, selectedTab) {
        if (selectedTab == 0) callHistory
        else callHistory.filter { it.direction == CallDirection.MISSED }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Call History",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                actions = {
                    TextButton(
                        onClick = onSimulateIncomingCall,
                        modifier = Modifier.testTag("simulate_incoming_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneCallback,
                            contentDescription = null,
                            tint = Color(0xFF0084FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Test Ringing",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0084FF)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onSimulateIncomingCall,
                containerColor = Color(0xFF0084FF),
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("new_call_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "New Call"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab row: All vs Missed
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = Color(0xFF0084FF)
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PhoneMissed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No calls recorded yet",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(filteredRecords, key = { it.id }) { call ->
                        CallRecordRow(
                            record = call,
                            onCallBack = { onCallBack(call) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CallRecordRow(
    record: CallRecord,
    onCallBack: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCallBack),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0084FF).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = record.avatarInitials,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0084FF)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = record.contactName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (record.direction == CallDirection.MISSED) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = when (record.direction) {
                                CallDirection.INCOMING -> Icons.Default.CallReceived
                                CallDirection.OUTGOING -> Icons.Default.CallMade
                                CallDirection.MISSED -> Icons.Default.CallMissed
                            },
                            contentDescription = null,
                            tint = when (record.direction) {
                                CallDirection.INCOMING -> Color(0xFF10B981)
                                CallDirection.OUTGOING -> Color(0xFF0084FF)
                                CallDirection.MISSED -> Color(0xFFEF4444)
                            },
                            modifier = Modifier.size(13.dp)
                        )

                        Text(
                            text = "${record.timestamp} • ${record.duration}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            IconButton(
                onClick = onCallBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0084FF).copy(alpha = 0.1f))
            ) {
                Icon(
                    imageVector = if (record.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                    contentDescription = "Call Again",
                    tint = Color(0xFF0084FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
