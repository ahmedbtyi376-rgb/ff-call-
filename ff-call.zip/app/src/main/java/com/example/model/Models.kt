package com.example.model

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

enum class MessageType {
    TEXT,
    VOICE,
    IMAGE,
    FILE
}

data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val avatarInitials: String,
    val avatarBgColor: Long = 0xFF0084FF,
    val isOnline: Boolean = true,
    val lastSeen: String = "Just now",
    val statusMessage: String = "Hey there! I am using FF Call.",
    val unreadCount: Int = 0
)

data class ChatMessage(
    val id: String,
    val contactId: String,
    val senderName: String,
    val isMe: Boolean,
    val text: String,
    val timestamp: String,
    val status: MessageStatus = MessageStatus.READ,
    val type: MessageType = MessageType.TEXT,
    val fileName: String? = null,
    val fileSize: String? = null,
    val voiceDurationSec: Int = 0,
    val isEncrypted: Boolean = true
)

enum class CallDirection {
    INCOMING,
    OUTGOING,
    MISSED
}

data class CallRecord(
    val id: String,
    val contactId: String,
    val contactName: String,
    val contactPhone: String,
    val avatarInitials: String,
    val direction: CallDirection,
    val isVideo: Boolean,
    val timestamp: String,
    val duration: String
)

data class CallSession(
    val contact: Contact,
    val isVideo: Boolean,
    val isIncoming: Boolean,
    val isConnected: Boolean = false,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isCameraOn: Boolean = true,
    val isScreenSharing: Boolean = false,
    val isFrontCamera: Boolean = true,
    val audioQualityStats: String = "WebRTC HD • 48kHz Opus • 24ms • 0% Loss"
)

data class RoomSpeaker(
    val name: String,
    val avatarChar: String,
    val isSpeaking: Boolean = false,
    val isMuted: Boolean = false
)

data class VoiceRoom(
    val id: String,
    val title: String,
    val hostName: String,
    val category: String,
    val membersCount: Int,
    val speakers: List<RoomSpeaker>,
    val isLive: Boolean = true
)

data class Story(
    val id: String,
    val authorName: String,
    val avatarChar: String,
    val timestamp: String,
    val caption: String,
    val bgGradientIndex: Int = 0,
    val isSeen: Boolean = false
)

data class WalletTransaction(
    val id: String,
    val title: String,
    val description: String,
    val amountTaka: Double,
    val timestamp: String,
    val isCredit: Boolean = true
)

data class AdMobConfig(
    val bannerUnitId: String = "ca-app-pub-3940256099942544/6300978111",
    val interstitialUnitId: String = "ca-app-pub-3940256099942544/1033173712",
    val rewardedUnitId: String = "ca-app-pub-3940256099942544/5224354917",
    val rewardAmountTaka: Double = 5.0,
    val isTestMode: Boolean = true,
    val isAdsEnabled: Boolean = true
)
