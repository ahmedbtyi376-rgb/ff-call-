package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDataRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FF Call", appName)
    }

    @Test
    fun `test rewarded video ad grants 5 taka bonus`() {
        val repository = AppDataRepository()
        val initialBalance = repository.walletBalance.value
        val rewardAmount = repository.adMobConfig.value.rewardAmountTaka

        repository.closeRewardedAd(wasCompleted = true)

        assertEquals(initialBalance + rewardAmount, repository.walletBalance.value, 0.001)
        assertTrue(repository.transactions.value.any { it.title.contains("Rewarded Video Ad") })
    }

    @Test
    fun `test call end triggers interstitial ad`() {
        val repository = AppDataRepository()
        val contact = repository.contacts.value.first()

        repository.startCall(contact, isVideo = true)
        repository.endCall()

        assertTrue(repository.showInterstitialAd.value)
        assertTrue(repository.callHistory.value.any { it.contactName == contact.name })
    }
}
